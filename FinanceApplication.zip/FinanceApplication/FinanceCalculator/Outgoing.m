//  Created by Waqar Malik  on 06/05/2015.
//  Copyright (c) 2015 Waqar Malik . All rights reserved.

#import "Outgoing.h"


@implementation Outgoing

@dynamic amount;
@dynamic category;
@dynamic costdescription;
@dynamic date;

@dynamic recuringswitch;


@end
