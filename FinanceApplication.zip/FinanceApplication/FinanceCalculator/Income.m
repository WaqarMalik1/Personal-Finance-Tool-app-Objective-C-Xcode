//  Created by Waqar Malik  on 06/05/2015.
//  Copyright (c) 2015 Waqar Malik . All rights reserved.

#import "Income.h"


@implementation Income

@dynamic amount;
@dynamic costdescription;
@dynamic date;
@dynamic category;
@dynamic ingoingrecuringswitch;


@end
