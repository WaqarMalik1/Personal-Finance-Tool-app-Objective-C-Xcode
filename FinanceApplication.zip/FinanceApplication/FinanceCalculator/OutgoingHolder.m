//  Created by Waqar Malik  on 06/05/2015.
//  Copyright (c) 2015 Waqar Malik . All rights reserved.


#import "OutgoingHolder.h"

@implementation OutgoingHolder

@end
